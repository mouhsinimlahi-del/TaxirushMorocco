Taxi Rush Morocco 🇲🇦 — Android v1.0

This project contains the final HTML game inside an Android WebView.

EASIEST BUILD (NO ANDROID STUDIO):
1. Create a GitHub account at github.com if you do not already have one.
2. Create a new repository.
3. Upload ALL files/folders from this project.
4. Open the Actions tab.
5. Run “Build Taxi Rush Morocco APK”.
6. When it finishes, open the workflow run and download the artifact named “Taxi-Rush-Morocco-APK”.
7. The downloaded ZIP contains app-debug.apk. Transfer it to the Android phone and install it.

The included GitHub Actions workflow builds the APK automatically.

For Google Play later: build a signed release AAB and complete Play Console requirements.
